import React, { useState, useEffect } from "react";
import { Container, Row, Col } from "react-bootstrap";
import Layout from "../../components/Layouts/Layout";

const Cart = ({ userArea, setShowPopup }) => {
  const user = JSON.parse(localStorage.getItem("currentUser"));
  const cartKey = `cart_${user?.email || "guest"}`;

  const [cartItems, setCartItems] = useState([]);
  const [form, setForm] = useState({ name: "", phone: "" });
  const [errors, setErrors] = useState({});
  const [receipt, setReceipt] = useState(null);
  const [step, setStep] = useState("cart"); // cart | checkout | receipt

  useEffect(() => {
    const stored = JSON.parse(localStorage.getItem(cartKey)) || [];
    const fixed = stored.map((item) => ({
      ...item,
      quantity: item.quantity || 1,
    }));
    setCartItems(fixed);

    // Pre-fill name if logged in
    if (user?.name) setForm((f) => ({ ...f, name: user.name }));
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const updateCart = (data) => {
    setCartItems(data);
    localStorage.setItem(cartKey, JSON.stringify(data));
  };

  const increaseQty = (id) => {
    updateCart(
      cartItems.map((item) =>
        item.id === id ? { ...item, quantity: (item.quantity || 1) + 1 } : item
      )
    );
  };

  const decreaseQty = (id) => {
    updateCart(
      cartItems.map((item) =>
        item.id === id
          ? { ...item, quantity: item.quantity > 1 ? item.quantity - 1 : 1 }
          : item
      )
    );
  };

  const removeItem = (id) => {
    updateCart(cartItems.filter((item) => item.id !== id));
  };

  const totalPrice = cartItems.reduce(
    (total, item) => total + (item.price || 0) * (item.quantity || 1),
    0
  );

  const totalItems = cartItems.reduce(
    (total, item) => total + (item.quantity || 1),
    0
  );

  // --- Delivery Area ---
  const getArea = () => {
    if (user) {
      const saved = JSON.parse(localStorage.getItem(`delivery_area_${user.email}`));
      return saved?.area || "Not specified";
    }
    const saved = JSON.parse(sessionStorage.getItem("delivery_area_guest"));
    return saved?.area || "Not specified";
  };

  // --- Validate ---
  const validate = () => {
    const errs = {};
    if (!form.name.trim()) errs.name = "Name is required";
    if (!form.phone.trim()) errs.phone = "Phone is required";
    else if (!/^[0-9]{10,13}$/.test(form.phone.replace(/\s/g, "")))
      errs.phone = "Enter a valid phone number";
    return errs;
  };

  // --- Place Order ---
  const handlePlaceOrder = () => {
    const errs = validate();
    if (Object.keys(errs).length > 0) {
      setErrors(errs);
      return;
    }

    const orderId = "ORD-" + Math.random().toString(36).substr(2, 8).toUpperCase();
    const orderTime = new Date().toLocaleString("en-PK", {
      dateStyle: "medium",
      timeStyle: "short",
    });

    const orderReceipt = {
      orderId,
      orderTime,
      name: form.name,
      phone: form.phone,
      area: getArea(),
      items: cartItems,
      totalItems,
      totalPrice,
      deliveryFee: 100,
      grandTotal: totalPrice + 100,
    };

    setReceipt(orderReceipt);
    setStep("receipt");

    // Clear cart
    localStorage.setItem(cartKey, JSON.stringify([]));
    setCartItems([]);
  };

  // --- Download Receipt ---
  const handleDownload = () => {
    const el = document.getElementById("receipt_box");
    const original = el.style.cssText;

    // Prepare for print
    el.style.cssText = `
      background: white !important;
      color: black !important;
      padding: 30px;
      max-width: 600px;
      margin: 0 auto;
    `;

    const printWindow = window.open("", "_blank");
    printWindow.document.write(`
      <html>
        <head>
          <title>Order Receipt - ${receipt.orderId}</title>
          <style>
            * { margin: 0; padding: 0; box-sizing: border-box; }
            body { font-family: Arial, sans-serif; background: #fff; color: #000; padding: 30px; }
            .receipt_header { text-align: center; border-bottom: 2px dashed #333; padding-bottom: 20px; margin-bottom: 20px; }
            .receipt_header h2 { font-size: 24px; color: #ff8800; }
            .receipt_header p { font-size: 13px; color: #555; margin-top: 5px; }
            .receipt_info { margin-bottom: 20px; }
            .receipt_info_row { display: flex; justify-content: space-between; padding: 6px 0; border-bottom: 1px solid #eee; font-size: 14px; }
            .receipt_info_row span:first-child { color: #555; }
            .receipt_info_row span:last-child { font-weight: 600; }
            .receipt_items { margin-bottom: 20px; }
            .receipt_items h4 { font-size: 15px; margin-bottom: 10px; border-bottom: 2px solid #ff8800; padding-bottom: 6px; }
            .receipt_item { display: flex; justify-content: space-between; padding: 7px 0; border-bottom: 1px solid #eee; font-size: 14px; }
            .receipt_totals { margin-top: 15px; }
            .receipt_total_row { display: flex; justify-content: space-between; padding: 6px 0; font-size: 14px; }
            .receipt_grand { font-size: 18px; font-weight: 700; color: #ff8800; border-top: 2px dashed #333; padding-top: 12px; margin-top: 8px; display: flex; justify-content: space-between; }
            .receipt_footer { text-align: center; margin-top: 25px; font-size: 13px; color: #888; border-top: 2px dashed #333; padding-top: 15px; }
          </style>
        </head>
        <body>
          <div class="receipt_header">
            <h2>🍔 Tasty Burgers</h2>
            <p>Order Confirmation</p>
            <p style="margin-top:8px; font-size:12px; color:#888;">Order ID: <strong>${receipt.orderId}</strong></p>
            <p style="font-size:12px; color:#888;">${receipt.orderTime}</p>
          </div>

          <div class="receipt_info">
            <div class="receipt_info_row"><span>Customer</span><span>${receipt.name}</span></div>
            <div class="receipt_info_row"><span>Phone</span><span>${receipt.phone}</span></div>
            <div class="receipt_info_row"><span>Delivery Area</span><span>${receipt.area}</span></div>
          </div>

          <div class="receipt_items">
            <h4>Order Items (${receipt.totalItems} items)</h4>
            ${receipt.items.map((item) => `
              <div class="receipt_item">
                <span>${item.title} × ${item.quantity}</span>
                <span>Rs. ${(item.price * item.quantity)}</span>
              </div>
            `).join("")}
          </div>

          <div class="receipt_totals">
            <div class="receipt_total_row"><span>Subtotal</span><span>Rs. ${receipt.totalPrice}</span></div>
            <div class="receipt_total_row"><span>Delivery Fee</span><span>Rs. ${receipt.deliveryFee}</span></div>
            <div class="receipt_grand"><span>Grand Total</span><span>Rs. ${receipt.grandTotal}</span></div>
          </div>

          <div class="receipt_footer">
            <p>Thank you for ordering from Tasty Burgers! 🍔</p>
            <p>Expected delivery: 30–45 minutes</p>
          </div>
        </body>
      </html>
    `);
    printWindow.document.close();
    printWindow.focus();
    setTimeout(() => {
      printWindow.print();
      printWindow.close();
    }, 500);

    el.style.cssText = original;
  };

  return (
    <Layout userArea={userArea} setShowPopup={setShowPopup}>
      <section className="cart_section">
        <Container>

          {/* ===== RECEIPT VIEW ===== */}
          {step === "receipt" && receipt && (
            <Row className="justify-content-center">
              <Col lg={7}>
                <div className="receipt_success">
                  <div className="receipt_success_icon">✅</div>
                  <h3>Order Placed Successfully!</h3>
                  <p>Your food is being prepared. Estimated delivery: 30–45 mins</p>
                </div>

                <div className="receipt_box" id="receipt_box">

                  {/* RECEIPT HEADER */}
                  <div className="receipt_head">
                    <h4>🍔 Tasty Burgers</h4>
                    <p>Order Confirmation</p>
                    <div className="receipt_id">{receipt.orderId}</div>
                    <small>{receipt.orderTime}</small>
                  </div>

                  {/* CUSTOMER INFO */}
                  <div className="receipt_section">
                    <h6>Customer Details</h6>
                    <div className="receipt_row">
                      <span>Name</span>
                      <span>{receipt.name}</span>
                    </div>
                    <div className="receipt_row">
                      <span>Phone</span>
                      <span>{receipt.phone}</span>
                    </div>
                    <div className="receipt_row">
                      <span>Delivery Area</span>
                      <span>{receipt.area}</span>
                    </div>
                  </div>

                  {/* ORDER ITEMS */}
                  <div className="receipt_section">
                    <h6>Order Items ({receipt.totalItems} items)</h6>
                    {receipt.items.map((item) => (
                      <div className="receipt_row" key={item.id}>
                        <span>{item.title} × {item.quantity}</span>
                        <span>Rs. {item.price * item.quantity}</span>
                      </div>
                    ))}
                  </div>

                  {/* TOTALS */}
                  <div className="receipt_section">
                    <div className="receipt_row">
                      <span>Subtotal</span>
                      <span>Rs. {receipt.totalPrice}</span>
                    </div>
                    <div className="receipt_row">
                      <span>Delivery Fee</span>
                      <span>Rs. {receipt.deliveryFee}</span>
                    </div>
                    <div className="receipt_grand">
                      <span>Grand Total</span>
                      <span>Rs. {receipt.grandTotal}</span>
                    </div>
                  </div>

                  {/* FOOTER */}
                  <div className="receipt_foot">
                    <p>Thank you for ordering from Tasty Burgers! 🍔</p>
                    <p>Expected delivery: 30–45 minutes</p>
                  </div>

                </div>

                {/* DOWNLOAD BUTTON */}
                <button
                  className="receipt_download_btn"
                  onClick={handleDownload}
                >
                  <i className="bi bi-download me-2"></i>
                  Download Receipt (PDF)
                </button>

              </Col>
            </Row>
          )}

          {/* ===== CART + CHECKOUT VIEW ===== */}
          {step !== "receipt" && (
            <>
              <h2 className="cart_title text-center mb-5">
                <i className="bi bi-bag-fill me-3"></i>Your Order
              </h2>

              {cartItems.length === 0 ? (
                <div className="empty_cart text-center">
                  <div style={{ fontSize: "4rem" }}>🍔</div>
                  <h4 className="mt-3">Your cart is empty</h4>
                  <p style={{ color: "#666" }}>Add some delicious burgers!</p>
                </div>
              ) : (
                <Row>

                  {/* LEFT — CART ITEMS */}
                  <Col lg={7} className="mb-4">
                    <div className="cart_box">
                      <h5 className="cart_box_title">
                        Cart Items
                        <span className="cart_badge">{totalItems}</span>
                      </h5>

                      {cartItems.map((item) => (
                        <div className="cart_item" key={item.id}>
                          <img
                            src={item.image}
                            alt={item.title}
                            className="cart_img"
                          />
                          <div className="cart_item_info">
                            <h6>{item.title}</h6>
                            <p>Rs. {item.price}</p>
                            <div className="qty_box">
                              <button onClick={() => decreaseQty(item.id)}>−</button>
                              <span className="qty">{item.quantity || 1}</span>
                              <button onClick={() => increaseQty(item.id)}>+</button>
                            </div>
                          </div>
                          <div className="cart_item_right">
                            <p className="cart_subtotal">
                              Rs. {(item.price || 0) * (item.quantity || 1)}
                            </p>
                            <button
                              className="cart_remove"
                              onClick={() => removeItem(item.id)}
                            >
                              <i className="bi bi-trash3"></i>
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </Col>

                  {/* RIGHT — SUMMARY + CHECKOUT */}
                  <Col lg={5}>

                    {/* ORDER SUMMARY */}
                    <div className="cart_box mb-4">
                      <h5 className="cart_box_title">Order Summary</h5>

                      <div className="summary_row">
                        <span>Subtotal ({totalItems} items)</span>
                        <span>Rs. {totalPrice}</span>
                      </div>
                      <div className="summary_row">
                        <span>Delivery Fee</span>
                        <span>Rs. 100</span>
                      </div>
                      <div className="summary_row">
                        <span>Delivery Area</span>
                        <span style={{ color: "#ffb200" }}>{getArea()}</span>
                      </div>
                      <div className="summary_total">
                        <span>Grand Total</span>
                        <span>Rs. {totalPrice + 100}</span>
                      </div>
                    </div>

                    {/* CHECKOUT FORM */}
                    <div className="cart_box">
                      <h5 className="cart_box_title">Delivery Details</h5>

                      <div className="checkout_field">
                        <label>Full Name</label>
                        <input
                          type="text"
                          placeholder="Enter your name"
                          value={form.name}
                          onChange={(e) =>
                            setForm({ ...form, name: e.target.value })
                          }
                          className={errors.name ? "input_error" : ""}
                        />
                        {errors.name && (
                          <small className="error_msg">{errors.name}</small>
                        )}
                      </div>

                      <div className="checkout_field">
                        <label>Phone Number</label>
                        <input
                          type="tel"
                          placeholder="03XX-XXXXXXX"
                          value={form.phone}
                          onChange={(e) =>
                            setForm({ ...form, phone: e.target.value })
                          }
                          className={errors.phone ? "input_error" : ""}
                        />
                        {errors.phone && (
                          <small className="error_msg">{errors.phone}</small>
                        )}
                      </div>

                      <div className="checkout_field">
  <label>
    Delivery Area
    <button
      type="button"
      onClick={() => setShowPopup(true)}
      style={{
        background: "none",
        border: "none",
        color: "#ffb200",
        fontSize: "12px",
        cursor: "pointer",
        marginLeft: "10px",
        fontFamily: "var(--roboto-font)",
        textDecoration: "underline",
      }}
    >
      <i className="bi bi-pencil-fill me-1"></i>
      Change
    </button>
  </label>
  <input
    type="text"
    value={getArea()}
    disabled
    className="input_disabled"
  />
</div>
                      <button
                        className="place_order_btn"
                        onClick={handlePlaceOrder}
                      >
                        <i className="bi bi-check-circle-fill me-2"></i>
                        Place Order — Rs. {totalPrice + 100}
                      </button>
                    </div>

                  </Col>
                </Row>
              )}
            </>
          )}

        </Container>
      </section>
    </Layout>
  );
};

export default Cart;