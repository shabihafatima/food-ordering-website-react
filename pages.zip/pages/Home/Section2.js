import React from "react";
import { Container, Row, Col } from "react-bootstrap";
import { Link } from "react-router-dom";
import Pizza from "../../assets/about/pizza.png";
import Salad from "../../assets/about/salad.png";
import Delivery from "../../assets/about/delivery-bike.png";

const mockData = [
  {
    image: Pizza,
    title: "Premium Quality Ingredients",
    paragraph:
      "We use fresh, high-quality ingredients to prepare every burger with care and perfection for the best taste experience.",
  },
  {
    image: Salad,
    title: "Healthy & Fresh Food",
    paragraph:
      "Our meals are prepared with fresh vegetables and hygienic methods to ensure both taste and health in every bite.",
  },
  {
    image: Delivery,
    title: "Super Fast Delivery",
    paragraph:
      "Get your favorite food delivered quickly and hot to your doorstep with our fast and reliable delivery service.",
  },
];

function Section2() {
  return (
    <>
      <section id="about" className="about_section">
        <Container>
          <Row>
            <Col lg={{ span: 8, offset: 2 }} className="text-center about_text">
              <h2>Delicious Burgers Made for Every Moment</h2>
              <p>
                We believe great food brings people together. Enjoy fresh,
                tasty and perfectly crafted burgers made just for you and your
                family.
              </p>
              <a href="#menu" className="btn order_now btn_red">
  Explore Full Menu
</a>
            </Col>
          </Row>
        </Container>
      </section>

      <section className="about_wrapper">
        <Container>
          <Row className="justify-content-center">
            {mockData.map((item, index) => (
              <Col md={6} lg={4} className="mb-4" key={index}>
                <div className="about_box text-center">
                  <div className="about_icon">
                    <img src={item.image} alt="icon" className="img-fluid" />
                  </div>
                  <h4>{item.title}</h4>
                  <p>{item.paragraph}</p>
                </div>
              </Col>
            ))}
          </Row>
        </Container>
      </section>
    </>
  );
}

export default Section2;