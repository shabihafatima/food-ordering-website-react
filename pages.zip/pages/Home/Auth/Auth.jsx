import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import "../../../styles/AuthStyle.css";

const getPasswordStrength = (password) => {
  let score = 0;
  if (password.length >= 8) score++;
  if (/[A-Z]/.test(password)) score++;
  if (/[0-9]/.test(password)) score++;
  if (/[!@#$%^&*(),.?":{}|<>]/.test(password)) score++;
  if (password.length >= 12) score++;
  if (score <= 1) return { label: "Weak", color: "#e3000e", width: "25%" };
  if (score === 2) return { label: "Fair", color: "#ff8800", width: "50%" };
  if (score === 3) return { label: "Good", color: "#ffb200", width: "75%" };
  return { label: "Strong", color: "#28a745", width: "100%" };
};

const validatePassword = (password) => {
  const errors = [];
  if (password.length < 8) errors.push("At least 8 characters");
  if (!/[A-Z]/.test(password)) errors.push("At least 1 uppercase letter");
  if (!/[0-9]/.test(password)) errors.push("At least 1 number");
  if (!/[!@#$%^&*(),.?":{}|<>]/.test(password))
    errors.push("At least 1 special character (!@#$%...)");
  return errors;
};

const Auth = () => {
  const navigate = useNavigate();
  const [isLogin, setIsLogin] = useState(true);
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);
  const [forgotMode, setForgotMode] = useState(false);
  const [forgotEmail, setForgotEmail] = useState("");
  const [forgotMsg, setForgotMsg] = useState("");
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const [passwordErrors, setPasswordErrors] = useState([]);
  const [strength, setStrength] = useState(null);
  const [form, setForm] = useState({
    name: "",
    phone: "",
    email: "",
    password: "",
    confirmPassword: "",
    rememberMe: false,
  });

  useEffect(() => {
    const remembered = localStorage.getItem("remembered_email");
    if (remembered) {
      setForm((f) => ({ ...f, email: remembered, rememberMe: true }));
    }
  }, []);

  const resetForm = () => {
    setError("");
    setSuccess("");
    setForgotMode(false);
    setStrength(null);
    setPasswordErrors([]);
    setShowPassword(false);
    setShowConfirm(false);
  };

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    const val = type === "checkbox" ? checked : value;
    setForm((f) => ({ ...f, [name]: val }));
    if (name === "password" && !isLogin) {
      setStrength(getPasswordStrength(value));
      setPasswordErrors(validatePassword(value));
    }
    setError("");
    setSuccess("");
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    setError("");
    setSuccess("");
    let users = JSON.parse(localStorage.getItem("users")) || [];

    if (!isLogin) {
      if (!form.name.trim()) {
        setError("Full name is required");
        return;
      }
      if (!/^03[0-9]{9}$/.test(form.phone.replace(/\s/g, ""))) {
        setError("Enter valid Pakistani phone (03XXXXXXXXX)");
        return;
      }
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) {
        setError("Enter a valid email address");
        return;
      }
      const pwdErrors = validatePassword(form.password);
      if (pwdErrors.length > 0) {
        setError("Password does not meet requirements");
        return;
      }
      if (form.password !== form.confirmPassword) {
        setError("Passwords do not match");
        return;
      }
      const exists = users.find((u) => u.email === form.email);
      if (exists) {
        setError("Account already exists with this email");
        return;
      }
      users.push({
        name: form.name,
        phone: form.phone,
        email: form.email,
        password: form.password,
      });
      localStorage.setItem("users", JSON.stringify(users));
      setSuccess("Account created! Please login.");
      setTimeout(() => {
        setIsLogin(true);
        resetForm();
        setForm((f) => ({
          ...f,
          password: "",
          confirmPassword: "",
        }));
      }, 1500);
      return;
    }

    if (!form.email.trim()) {
      setError("Email is required");
      return;
    }
    if (!form.password.trim()) {
      setError("Password is required");
      return;
    }
    const validUser = users.find(
      (u) => u.email === form.email && u.password === form.password
    );
    if (validUser) {
      if (form.rememberMe) {
        localStorage.setItem("remembered_email", form.email);
      } else {
        localStorage.removeItem("remembered_email");
      }
      localStorage.setItem("currentUser", JSON.stringify(validUser));
      setSuccess("Login successful! Redirecting...");
      setTimeout(() => navigate("/"), 1000);
    } else {
      setError("Invalid email or password");
    }
  };

  const handleForgot = (e) => {
    e.preventDefault();
    setForgotMsg("");
    if (!forgotEmail) {
      setForgotMsg("error:Please enter your email first");
      return;
    }
    const users = JSON.parse(localStorage.getItem("users")) || [];
    const found = users.find((u) => u.email === forgotEmail);
    if (!found) {
      setForgotMsg("error:No account found with this email");
      return;
    }
    setForgotMsg("success:Your password is: " + found.password);
  };

  function BackLink() {
  return (
    <div style={{ textAlign: "center", marginTop: "15px" }}>
      <a href="/" style={{ color: "#555", fontSize: "13px", textDecoration: "none" }}>
        {"← Back to Website"}
      </a>
    </div>
  );
}
  return (
    <section className="auth_section">

      {/* LEFT */}
      <div className="auth_left">
        <div className="auth_brand">
          <div className="auth_logo">🍔</div>
          <h1>Tasty Burgers</h1>
          <p>Fresh, Hot and Delivered Fast</p>
          <div className="auth_features">
            <div className="auth_feature_item">
              <i className="bi bi-lightning-fill"></i>
              <span>30 min delivery</span>
            </div>
            <div className="auth_feature_item">
              <i className="bi bi-shield-fill-check"></i>
              <span>100% fresh ingredients</span>
            </div>
            <div className="auth_feature_item">
              <i className="bi bi-star-fill"></i>
              <span>Top rated in Gujranwala</span>
            </div>
          </div>
        </div>
      </div>

      {/* RIGHT */}
      <div className="auth_right">
        <div className="auth_form_box">

          {forgotMode ? (

            /* FORGOT PASSWORD */
            <div className="forgot_box">
              <button
                className="back_btn"
                onClick={() => {
                  setForgotMode(false);
                  setForgotMsg("");
                  setForgotEmail("");
                }}
              >
                <i className="bi bi-arrow-left me-2"></i>
                Back to Login
              </button>

              <h4>Forgot Password?</h4>
              <p>Enter your registered email to recover your password.</p>

              <div className="auth_field">
                <label>Email Address</label>
                <div className="auth_input_wrap">
                  <i className="bi bi-envelope-fill auth_input_icon"></i>
                  <input
                    type="email"
                    placeholder="your@email.com"
                    value={forgotEmail}
                    onChange={(e) => {
                      setForgotEmail(e.target.value);
                      setForgotMsg("");
                    }}
                  />
                </div>
              </div>

              {forgotMsg && (
                <div
                  className={
                    "auth_msg " +
                    (forgotMsg.startsWith("error")
                      ? "auth_error"
                      : "auth_success")
                  }
                >
                {forgotMsg.substring(forgotMsg.indexOf(":") + 1)}
                </div>
              )}

              <button
                className="auth_submit_btn"
                onClick={handleForgot}
              >
                Find My Account
              </button>

              <BackLink />
            </div>

          ) : (

            /* LOGIN / SIGNUP */
            <form onSubmit={handleSubmit}>

              {/* TABS */}
              <div className="auth_tabs">
                <button
                  type="button"
                  className={"auth_tab " + (isLogin ? "active" : "")}
                  onClick={() => {
                    setIsLogin(true);
                    resetForm();
                  }}
                >
                  Login
                </button>
                <button
                  type="button"
                  className={"auth_tab " + (!isLogin ? "active" : "")}
                  onClick={() => {
                    setIsLogin(false);
                    resetForm();
                  }}
                >
                  Sign Up
                </button>
              </div>

              <h3 className="auth_form_title">
                {isLogin ? "Welcome Back 👋" : "Create Account"}
              </h3>
              <p className="auth_form_sub">
                {isLogin
                  ? "Login to continue ordering"
                  : "Join us and start ordering"}
              </p>

              {error && (
                <div className="auth_msg auth_error">{error}</div>
              )}
              {success && (
                <div className="auth_msg auth_success">{success}</div>
              )}

              {/* NAME */}
              {!isLogin && (
                <div className="auth_field">
                  <label>Full Name</label>
                  <div className="auth_input_wrap">
                    <i className="bi bi-person-fill auth_input_icon"></i>
                    <input
                      name="name"
                      type="text"
                      placeholder="Ali Ahmed"
                      value={form.name}
                      onChange={handleChange}
                    />
                  </div>
                </div>
              )}

              {/* PHONE */}
{!isLogin && (
  <div className="auth_field">
    <label>Phone Number</label>
    <div className="auth_input_wrap">
      <i className="bi bi-telephone-fill auth_input_icon"></i>
      <input
        name="phone"
        type="tel"
        placeholder="03001234567"
        value={form.phone}
        onChange={handleChange}
        maxLength={11}
      />
    </div>
    <small style={{
      color: "#555",
      fontSize: "12px",
      marginTop: "6px",
      display: "block"
    }}>
      Pakistani number only — start with 03, total 11 digits. Example: 03001234567
    </small>
    {form.phone && !/^03[0-9]{9}$/.test(form.phone) && (
      <small style={{
        color: "#e3000e",
        fontSize: "12px",
        marginTop: "4px",
        display: "block"
      }}>
        ✗ Must be 11 digits starting with 03
      </small>
    )}
    {form.phone && /^03[0-9]{9}$/.test(form.phone) && (
      <small style={{
        color: "#28a745",
        fontSize: "12px",
        marginTop: "4px",
        display: "block"
      }}>
        ✓ Valid phone number
      </small>
    )}
  </div>
)}

              {/* EMAIL */}
              <div className="auth_field">
                <label>Email Address</label>
                <div className="auth_input_wrap">
                  <i className="bi bi-envelope-fill auth_input_icon"></i>
                  <input
                    name="email"
                    type="email"
                    placeholder="your@email.com"
                    value={form.email}
                    onChange={handleChange}
                  />
                </div>
              </div>

              {/* PASSWORD */}
              <div className="auth_field">
                <label>Password</label>
                <div className="auth_input_wrap">
                  <i className="bi bi-lock-fill auth_input_icon"></i>
                  <input
                    name="password"
                    type={showPassword ? "text" : "password"}
                    placeholder="••••••••"
                    value={form.password}
                    onChange={handleChange}
                  />
                  <button
                    type="button"
                    className="auth_eye"
                    onClick={() => setShowPassword(!showPassword)}
                  >
                    <i
                      className={
                        "bi " +
                        (showPassword
                          ? "bi-eye-slash-fill"
                          : "bi-eye-fill")
                      }
                    ></i>
                  </button>
                </div>

                {!isLogin && form.password && strength && (
                  <div className="strength_wrap">
                    <div className="strength_bar">
                      <div
                        className="strength_fill"
                        style={{
                          width: strength.width,
                          background: strength.color,
                        }}
                      ></div>
                    </div>
                    <span style={{ color: strength.color }}>
                      {strength.label}
                    </span>
                  </div>
                )}

                {!isLogin && form.password && passwordErrors.length > 0 && (
                  <ul className="pwd_rules">
                    {passwordErrors.map((err, i) => (
                      <li key={i}>
                        <i className="bi bi-x-circle-fill"></i> {err}
                      </li>
                    ))}
                  </ul>
                )}

                {!isLogin && form.password && passwordErrors.length === 0 && (
                  <ul className="pwd_rules">
                    <li className="pwd_ok">
                      <i className="bi bi-check-circle-fill"></i> Password looks great!
                    </li>
                  </ul>
                )}
              </div>

              {/* CONFIRM PASSWORD */}
              {!isLogin && (
                <div className="auth_field">
                  <label>Confirm Password</label>
                  <div className="auth_input_wrap">
                    <i className="bi bi-lock-fill auth_input_icon"></i>
                    <input
                      name="confirmPassword"
                      type={showConfirm ? "text" : "password"}
                      placeholder="••••••••"
                      value={form.confirmPassword}
                      onChange={handleChange}
                    />
                    <button
                      type="button"
                      className="auth_eye"
                      onClick={() => setShowConfirm(!showConfirm)}
                    >
                      <i
                        className={
                          "bi " +
                          (showConfirm
                            ? "bi-eye-slash-fill"
                            : "bi-eye-fill")
                        }
                      ></i>
                    </button>
                  </div>
                  {form.confirmPassword && (
                    <small
                      style={{
                        color:
                          form.password === form.confirmPassword
                            ? "#28a745"
                            : "#e3000e",
                        fontSize: "12px",
                        marginTop: "5px",
                        display: "block",
                      }}
                    >
                      {form.password === form.confirmPassword
                        ? "✓ Passwords match"
                        : "✗ Passwords do not match"}
                    </small>
                  )}
                </div>
              )}

              {/* REMEMBER ME + FORGOT */}
              {isLogin && (
                <div className="auth_remember">
                  <label className="remember_label">
                    <input
                      type="checkbox"
                      name="rememberMe"
                      checked={form.rememberMe}
                      onChange={handleChange}
                    />
                    <span>Remember Me</span>
                  </label>
                  <button
                    type="button"
                    className="forgot_link"
                    onClick={() => setForgotMode(true)}
                  >
                    Forgot Password?
                  </button>
                </div>
              )}

              {/* SUBMIT */}
              <button type="submit" className="auth_submit_btn">
                {isLogin ? "Login to Account" : "Create Account"}
              </button>

              <BackLink />

            </form>
          )}

        </div>
      </div>

    </section>
  );
};

export default Auth;