import React, { useState } from "react";
import { Container, Row, Col } from "react-bootstrap";
import Image1 from "../../assets/menu/burger-11.jpg";
import Image2 from "../../assets/menu/burger-12.jpg";
import Image3 from "../../assets/menu/burger-13.jpg";
import Image4 from "../../assets/menu/burger-14.jpg";
import Image5 from "../../assets/menu/burger-15.jpg";
import Image6 from "../../assets/menu/burger-16.jpg";
import Image7 from "../../assets/menu/burger-17.jpg";
import Image8 from "../../assets/menu/burger-18.jpg";
import Fries1 from "../../assets/menu/ads-1.jpg";
import Fries2 from "../../assets/menu/ads-2.jpg";

const mockData = [
  { id: "0001", image: Image1, title: "Crispy Chicken", paragraph: "Chicken breast, chilli sauce, tomatoes, pickles, coleslaw", price: 850 },
  { id: "0002", image: Image2, title: "Ultimate Bacon", paragraph: "House patty, cheddar cheese, bacon, onion, mustard", price: 950 },
  { id: "0003", image: Image3, title: "Black Sheep", paragraph: "American cheese, tomato relish, avocado, lettuce, red onion", price: 780 },
  { id: "0004", image: Image4, title: "Vegan Burger", paragraph: "Fresh veggies, cheddar cheese, onion, mustard", price: 820 },
  { id: "0005", image: Image5, title: "Double Burger", paragraph: "2 patties, cheddar cheese, mustard, pickles, tomatoes", price: 1100 },
  { id: "0006", image: Image6, title: "Turkey Burger", paragraph: "Turkey, cheddar cheese, onion, lettuce, tomatoes", price: 920 },
  { id: "0007", image: Image7, title: "Smokey House", paragraph: "Smoked patty, cheddar cheese, lettuce, tomatoes", price: 990 },
  { id: "0008", image: Image8, title: "Classic Burger", paragraph: "Cheddar cheese, ketchup, mustard, pickles, onion", price: 700 },
  { id: "0009", image: Fries1, title: "Cheese Fries", paragraph: "Loaded fries with creamy cheese and spicy sauce", price: 450 },
  { id: "0010", image: Fries2, title: "Loaded Fries", paragraph: "Crispy fries topped with cheese and jalapenos", price: 520 },
];

function Section3() {
  const [favorites, setFavorites] = useState([]);
  const [addedItems, setAddedItems] = useState([]);

  // ✅ FIXED: Save to localStorage
  const handleAddToCart = (item) => {
    const user = JSON.parse(localStorage.getItem("currentUser"));
    const cartKey = `cart_${user?.email || "guest"}`;

    const existingCart = JSON.parse(localStorage.getItem(cartKey)) || [];

    // If item already in cart, increase quantity
    const existingIndex = existingCart.findIndex((i) => i.id === item.id);
    if (existingIndex !== -1) {
      existingCart[existingIndex].quantity += 1;
    } else {
      existingCart.push({ ...item, quantity: 1 });
    }

    localStorage.setItem(cartKey, JSON.stringify(existingCart));

    // Show "Added!" feedback
    setAddedItems((prev) => [...prev, item.id]);
    setTimeout(() => {
      setAddedItems((prev) => prev.filter((id) => id !== item.id));
    }, 1000);
  };

  const toggleFavorite = (id) => {
    if (favorites.includes(id)) {
      setFavorites(favorites.filter((item) => item !== id));
    } else {
      setFavorites([...favorites, id]);
    }
  };

  return (
    <section id="menu" className="menu_section">
      <Container>
        <Row>
          <Col lg={{ span: 8, offset: 2 }} className="text-center mb-5">
            <h2>OUR CRAZY BURGERS</h2>
            <p className="para">Fresh burgers made with premium ingredients and delicious flavors.</p>
          </Col>
        </Row>
        <Row>
          {mockData.map((cardData) => (
            <Col lg={3} md={6} sm={6} xs={12} key={cardData.id}>
              <div className="menu_card">
                <button className="wishlist_btn" onClick={() => toggleFavorite(cardData.id)}>
                  <i className={favorites.includes(cardData.id) ? "bi bi-heart-fill" : "bi bi-heart"}></i>
                </button>
                <div className="menu_img">
                  <img src={cardData.image} alt={cardData.title} className="img-fluid" />
                </div>
                <div className="menu_content">
                  <h5>{cardData.title}</h5>
                  <p>{cardData.paragraph}</p>
                  <h6>Rs. {cardData.price}</h6>
                  <button
                    className="btn btn_red w-100 add_btn"
                    onClick={() => handleAddToCart(cardData)}
                  >
                    {addedItems.includes(cardData.id) ? "✔ Added!" : "Add To Cart"}
                  </button>
                </div>
              </div>
            </Col>
          ))}
        </Row>
      </Container>
    </section>
  );
}

export default Section3;