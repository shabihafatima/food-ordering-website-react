import React from "react";
import { Container, Row, Col } from "react-bootstrap";
import { Link } from "react-router-dom";

function Section7() {
  return (
    <section id="contact" className="contact_section">
      <Container>
        <Row className="justify-content-center">
          <Col sm={8} className="text-center">
            <h4>Fast & Fresh Delivery</h4>

            <h2>Hot Burgers Delivered In 30 Minutes!</h2>

            <p>
              Enjoy juicy burgers, crispy fries, and refreshing drinks made
              with fresh ingredients and delivered straight to your doorstep
              quickly and safely.
            </p>

            <Link
              to="tel:+923001234567"
              className="btn btn_red px-4 py-2 rounded-0"
            >
              Call: +92 300 1234567
            </Link>
          </Col>
        </Row>
      </Container>
    </section>
  );
}

export default Section7;