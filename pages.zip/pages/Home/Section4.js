import React from "react";
import { Container, Row, Col } from "react-bootstrap";
import PromotionImage from "../../assets/promotion/pro.png";

function Section4() {
  return (
    <>
      <section className="promotion_section">
        <Container>
          <Row className="align-items-center">
            <Col lg={6} className="text-center mb-5 mb-lg-0">
              <img src={PromotionImage} className="img-fluid" alt="Promotion" />
            </Col>
            <Col lg={6} className="px-5">
              <h2>Nothing brings people together like a good burger</h2>
              <p>
               Freshly prepared meals made with premium ingredients and rich flavors. 
Enjoy delicious burgers, crispy fries, and refreshing drinks crafted 
to give you the perfect dining experience every time.
              </p>
              <ul>
                <li>
                  <p>
                    Delicious food made with fresh ingredients, rich flavors, and premium quality to give you a satisfying and memorable taste experience.
                  </p>
                </li>
                <li>
                  <p>Fresh flavors and premium ingredients combined to create the perfect delicious meal experience.</p>
                </li>
                <li>
                  <p>
                    Enjoy delicious meals made with fresh ingredients, rich flavors, and quality recipes crafted for a perfect food experience.
                  </p>
                </li>
              </ul>
            </Col>
          </Row>
        </Container>
      </section>

      {/* BG Parallax Scroll */}
      <section className="bg_parallax_scroll"></section>
    </>
  );
}

export default Section4;
