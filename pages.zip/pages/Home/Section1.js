import React from "react";
import { Container, Row, Col } from "react-bootstrap";

const Section1 = () => {
  const scrollToMenu = () => {
    const menu = document.getElementById("menu");
    if (menu) {
      menu.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <section id="home" className="hero_section">
      <Container>
        <Row className="justify-content-end">
          <Col lg={6} md={8} className="text-center text-lg-end">
            <div className="hero_text">
              <h1>Tasty Burgers</h1>
              <h2>Fresh, Hot & Delicious</h2>
              <p>
                Enjoy premium burgers, crispy fries,
                cold drinks, and fast delivery with amazing taste.
              </p>
              <button
                className="btn order_now mt-3"
                onClick={scrollToMenu}
              >
                Order Now
              </button>
            </div>
          </Col>
        </Row>
      </Container>
    </section>
  );
};

export default Section1;