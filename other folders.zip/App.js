import React, { useState, useEffect } from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Home from "./pages/Home/Home";
import Auth from "./pages/Home/Auth/Auth";
import Cart from "./pages/Cart/Cart";
import DeliveryPopup from "./components/Layouts/DeliveryPopup";
import Loader from "./components/Layouts/Loader";

function App() {
  const [showPopup, setShowPopup] = useState(false);
  const [userArea, setUserArea] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const user = JSON.parse(localStorage.getItem("currentUser"));
    if (user) {
      const saved = JSON.parse(localStorage.getItem(`delivery_area_${user.email}`));
      if (saved?.area) { setUserArea(saved.area); }
      else { setShowPopup(true); }
    } else {
      const saved = JSON.parse(sessionStorage.getItem("delivery_area_guest"));
      if (saved?.area) { setUserArea(saved.area); }
      else { setShowPopup(true); }
    }
  }, []);

  const handlePopupClose = (area) => {
    setUserArea(area);
    setShowPopup(false);
  };

  return (
    <Router>
      {loading && <Loader onComplete={() => setLoading(false)} />}
      {!loading && showPopup && <DeliveryPopup onClose={handlePopupClose} />}
      <Routes>
        <Route path="/" element={<Home userArea={userArea} setUserArea={setUserArea} setShowPopup={setShowPopup} />} />
        <Route path="/auth" element={<Auth />} />
        <Route path="/cart" element={<Cart userArea={userArea} setShowPopup={setShowPopup} />} />
      </Routes>
    </Router>
  );
}

export default App;