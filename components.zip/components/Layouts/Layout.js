import React from "react";
import Header from "./Header";
import Footer from "./Footer";

function Layout({ children, userArea, setShowPopup }) {
  return (
    <>
      <Header userArea={userArea} setShowPopup={setShowPopup} />
      <div>{children}</div>
      <Footer />
    </>
  );
}

export default Layout;