import React, { useState, useEffect } from "react";
import { Container, Row, Col } from "react-bootstrap";
import { Link } from "react-router-dom";

function Footer() {
  // Scroll State
  const [isVisible, setIsVisible] = useState(false);

  const scrollTop = () => {
    window.scrollTo({
      top: 0,
      behavior: "smooth",
    });
  };

  const listenToScroll = () => {
    let heightToHidden = 250;

    const windowScroll =
      document.body.scrollTop || document.documentElement.scrollTop;

    windowScroll > heightToHidden
      ? setIsVisible(true)
      : setIsVisible(false);
  };

  useEffect(() => {
    window.addEventListener("scroll", listenToScroll);

    return () => {
      window.removeEventListener("scroll", listenToScroll);
    };
  }, []);

  return (
    <>
      <footer>
        <Container>
          <Row>
            {/* Location */}
            <Col sm={6} lg={3} className="mb-4 mb-lg-0">
              <div className="text-center">
                <h5>Location</h5>
                <p>123 Food Street</p>
                <p>Downtown Restaurant Hub</p>
                <p>Gujranwala, Pakistan</p>
              </div>
            </Col>

            {/* Working Hours */}
            <Col sm={6} lg={3} className="mb-4 mb-lg-0">
              <div className="text-center">
                <h5>Working Hours</h5>
                <p>Monday - Friday: 10:00AM - 11:00PM</p>
                <p>Saturday: 11:00AM - 12:00AM</p>
                <p>Sunday: 12:00PM - 10:00PM</p>
              </div>
            </Col>

            {/* Order Now */}
            <Col sm={6} lg={3} className="mb-4 mb-lg-0">
              <div className="text-center">
                <h5>Order Now</h5>
                <p>Fresh Burgers, Fries & Drinks Delivered Fast</p>

                <p>
                  <Link to="tel:+923001234567" className="calling">
                    +92 300 1234567
                  </Link>
                </p>
              </div>
            </Col>

            {/* Social Links */}
            <Col sm={6} lg={3} className="mb-4 mb-lg-0">
              <div className="text-center">
                <h5>Follow Us</h5>
                <p>Stay connected for latest deals & offers</p>

                <ul className="list-unstyled text-center mt-2 d-flex justify-content-center gap-3">
                  <li>
                    <Link to="/">
                      <i className="bi bi-facebook"></i>
                    </Link>
                  </li>

                  <li>
                    <Link to="/">
                      <i className="bi bi-twitter"></i>
                    </Link>
                  </li>

                  <li>
                    <Link to="/">
                      <i className="bi bi-instagram"></i>
                    </Link>
                  </li>

                  <li>
                    <Link to="/">
                      <i className="bi bi-youtube"></i>
                    </Link>
                  </li>
                </ul>
              </div>
            </Col>
          </Row>

          {/* Copyright */}
          <Row className="copy_right">
            <Col>
              <div>
                <ul className="list-unstyled text-center mb-0 d-flex justify-content-center flex-wrap gap-3">
                  <li>
                    <Link to="/">
                      © 2026 <span>BURGER HOUSE</span>. All Rights Reserved
                    </Link>
                  </li>

                  <li>
                    <Link to="/">About Us</Link>
                  </li>

                  <li>
                    <Link to="/">Terms Of Use</Link>
                  </li>

                  <li>
                    <Link to="/">Privacy Policy</Link>
                  </li>
                </ul>
              </div>
            </Col>
          </Row>
        </Container>
      </footer>

      {/* Scroll To Top */}
      {isVisible && (
        <div className="scroll_top" onClick={scrollTop}>
          <i className="bi bi-arrow-up"></i>
        </div>
      )}
    </>
  );
}

export default Footer;