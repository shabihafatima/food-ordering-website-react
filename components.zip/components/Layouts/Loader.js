import React, { useState, useEffect } from "react";
import "../../styles/Loader.css";
import Logo from "../../assets/logo/logo.png";

function Loader({ onComplete }) {
  const [stage, setStage] = useState(0);
  // stage 0 = logo spins in
  // stage 1 = name appears
  // stage 2 = tagline appears
  // stage 3 = fade out

  useEffect(() => {
    const t1 = setTimeout(() => setStage(1), 600);
    const t2 = setTimeout(() => setStage(2), 1400);
    const t3 = setTimeout(() => setStage(3), 2400);
    const t4 = setTimeout(() => onComplete(), 3000);

    return () => {
      clearTimeout(t1);
      clearTimeout(t2);
      clearTimeout(t3);
      clearTimeout(t4);
    };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <div className={`ld_overlay ${stage === 3 ? "ld_fadeout" : ""}`}>

      {/* BACKGROUND BLOBS */}
      <div className="ld_blob ld_blob1"></div>
      <div className="ld_blob ld_blob2"></div>
      <div className="ld_blob ld_blob3"></div>

      {/* SCANLINE EFFECT */}
      <div className="ld_scanline"></div>

      <div className="ld_center">

        {/* SPINNING LOGO */}
        <div className={`ld_logo_wrap ${stage >= 0 ? "ld_spin_in" : ""}`}>
          <div className="ld_logo_ring"></div>
          <div className="ld_logo_ring2"></div>
          <img src={Logo} alt="Logo" className="ld_logo_img" />
        </div>

        {/* RESTAURANT NAME */}
        <div className={`ld_name ${stage >= 1 ? "ld_appear" : ""}`}>
          {"TASTY BURGERS".split("").map((char, i) => (
            <span
              key={i}
              className="ld_letter"
              style={{ animationDelay: `${i * 0.06}s` }}
            >
              {char === " " ? "\u00A0" : char}
            </span>
          ))}
        </div>

        {/* TAGLINE */}
        <div className={`ld_tagline ${stage >= 2 ? "ld_appear" : ""}`}>
          <span className="ld_line"></span>
          <span className="ld_tagline_text">Fresh · Hot · Delivered Fast</span>
          <span className="ld_line"></span>
        </div>

        {/* DOTS LOADER */}
        <div className={`ld_dots ${stage >= 2 ? "ld_appear" : ""}`}>
          <span></span>
          <span></span>
          <span></span>
        </div>

      </div>

    </div>
  );
}

export default Loader;