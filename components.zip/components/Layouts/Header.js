import React, { useState, useEffect } from "react";
import { Container, Nav, Navbar } from "react-bootstrap";
import { Link } from "react-router-dom";
import Logo from "../../assets/logo/logo.png";
import "../../styles/HeaderStyle.css";
import CartDrawer from "./CartDrawer";

const Header = ({ userArea, setShowPopup }) => {

  const user = JSON.parse(localStorage.getItem("currentUser"));
  const [cartCount, setCartCount] = useState(0);
  const [cartItems, setCartItems] = useState([]);
  const [isOpen, setIsOpen] = useState(true);
  const [cartOpen, setCartOpen] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    const updateAll = () => {
      const cartKey = `cart_${user?.email || "guest"}`;
      const cart = JSON.parse(localStorage.getItem(cartKey)) || [];
      const total = cart.reduce((sum, item) => sum + (item.quantity || 1), 0);
      setCartCount(total);
      setCartItems(cart);

      const hour = new Date().getHours();
      const open = hour >= 16 || hour < 3;
      setIsOpen(open);
    };

    updateAll();
    const interval = setInterval(updateAll, 5000);
    return () => clearInterval(interval);

  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const cartKey = `cart_${user?.email || "guest"}`;

  const updateCart = (updated) => {
    setCartItems(updated);
    localStorage.setItem(cartKey, JSON.stringify(updated));
    const total = updated.reduce((sum, item) => sum + (item.quantity || 1), 0);
    setCartCount(total);
  };

  const handleIncrease = (id) => {
    const updated = cartItems.map((item) =>
      item.id === id ? { ...item, quantity: (item.quantity || 1) + 1 } : item
    );
    updateCart(updated);
  };

  const handleDecrease = (id) => {
    const updated = cartItems.map((item) =>
      item.id === id
        ? { ...item, quantity: item.quantity > 1 ? item.quantity - 1 : 1 }
        : item
    );
    updateCart(updated);
  };

  const handleRemove = (id) => {
    const updated = cartItems.filter((item) => item.id !== id);
    updateCart(updated);
  };

  const handleLogout = () => {
    localStorage.removeItem("currentUser");
    window.location.href = "/";
  };

  const handleChangeArea = () => {
    const u = JSON.parse(localStorage.getItem("currentUser"));
    if (u) {
      localStorage.removeItem(`delivery_area_${u.email}`);
    } else {
      sessionStorage.removeItem("delivery_area_guest");
    }
    setShowPopup(true);
  };

  return (
    <>
      <header>

        {/* 🔴 CLOSED BANNER */}
        {!isOpen && (
          <div className="closed_banner">
            <i className="bi bi-clock-fill me-2"></i>
            Oops! We're not delivering right now. Come back between 4PM – 3AM 🕛
          </div>
        )}

        <Navbar expand="lg" className="custom_navbar">
          <Container>

            {/* LOGO */}
            <Navbar.Brand>
              <Link to="/" className="logo d-flex align-items-center text-decoration-none">
                <img src={Logo} alt="Logo" className="img-fluid me-2" />
                <h3 className="brand_name m-0">Tasty Burgers</h3>
              </Link>
            </Navbar.Brand>

            {/* ✅ MOBILE RIGHT ICONS — always visible */}
            <div className="mobile_icons d-flex d-lg-none align-items-center gap-2">

              {/* 📍 AREA */}
              <button
                onClick={handleChangeArea}
                className="area_badge_mobile"
                title="Change delivery area"
              >
                <i className="bi bi-geo-alt-fill"></i>
                <span>{userArea ? userArea : "Area"}</span>
              </button>

              {/* 🛒 CART */}
              <button
                className="cart_mobile"
                onClick={() => setCartOpen(true)}
              >
                <i className="bi bi-bag-fill"></i>
                {cartCount > 0 && (
                  <em className="roundpoint">{cartCount}</em>
                )}
              </button>

              {/* ☰ HAMBURGER */}
              <button
                className="hamburger_btn"
                onClick={() => setMenuOpen(true)}
              >
                <i className="bi bi-list"></i>
              </button>

            </div>

            {/* ✅ DESKTOP NAV — only shows on lg+ */}
            <div className="d-none d-lg-flex ms-auto align-items-center">
              <Nav className="align-items-center">

               <Nav.Link onClick={() => window.location.href = "/#home"}>Home</Nav.Link>
<Nav.Link onClick={() => window.location.href = "/#about"}>About</Nav.Link>
<Nav.Link onClick={() => window.location.href = "/#menu"}>Menu</Nav.Link>
<Nav.Link onClick={() => window.location.href = "/#blog"}>Blog</Nav.Link>
<Nav.Link onClick={() => window.location.href = "/#contact"}>Contact</Nav.Link>
                {user ? (
                  <Nav.Link onClick={handleLogout}>Logout</Nav.Link>
                ) : (
                  <Nav.Link as={Link} to="/auth">Login</Nav.Link>
                )}

                {/* 📍 AREA BADGE */}
                <Nav.Link
                  onClick={handleChangeArea}
                  className="area_badge"
                  title="Click to change delivery area"
                >
                  <i className="bi bi-geo-alt-fill"></i>
                  <span>{userArea ? userArea : "Select Area"}</span>
                </Nav.Link>

                {/* 🛒 CART */}
                <Nav.Link onClick={() => setCartOpen(true)}>
                  <div className="cart">
                    <i className="bi bi-bag-fill fs-5"></i>
                    {cartCount > 0 && (
                      <em className="roundpoint">{cartCount}</em>
                    )}
                  </div>
                </Nav.Link>

              </Nav>
            </div>

          </Container>
        </Navbar>

        {/* ✅ MOBILE SIDEBAR MENU */}
        <div
          className={`mobile_overlay ${menuOpen ? "active" : ""}`}
          onClick={() => setMenuOpen(false)}
        ></div>

        <div className={`mobile_sidebar ${menuOpen ? "active" : ""}`}>

          {/* SIDEBAR HEADER */}
          <div className="sidebar_header">
            <div className="sidebar_logo">
              <img src={Logo} alt="Logo" className="img-fluid" />
              <span>Tasty Burgers</span>
            </div>
            <button
              className="sidebar_close"
              onClick={() => setMenuOpen(false)}
            >
              <i className="bi bi-x-lg"></i>
            </button>
          </div>

          {/* SIDEBAR LINKS */}
          <div className="sidebar_links">
     <a href="/#home" onClick={() => { setMenuOpen(false); window.location.href = "/#home"; }}>
  <i className="bi bi-house-fill"></i> Home
</a>
<a href="/#about" onClick={() => { setMenuOpen(false); window.location.href = "/#about"; }}>
  <i className="bi bi-info-circle-fill"></i> About
</a>
<a href="/#menu" onClick={() => { setMenuOpen(false); window.location.href = "/#menu"; }}>
  <i className="bi bi-grid-fill"></i> Menu
</a>
<a href="/#blog" onClick={() => { setMenuOpen(false); window.location.href = "/#blog"; }}>
  <i className="bi bi-chat-quote-fill"></i> Blog
</a>
<a href="/#contact" onClick={() => { setMenuOpen(false); window.location.href = "/#contact"; }}>
  <i className="bi bi-telephone-fill"></i> Contact
</a>
          </div>

          {/* DIVIDER */}
          <div className="sidebar_divider"></div>

          {/* AUTH */}
          <div className="sidebar_auth">
            {user ? (
              <button
                className="sidebar_logout"
                onClick={handleLogout}
              >
                <i className="bi bi-box-arrow-right"></i> Logout
              </button>
            ) : (
              <Link
                to="/auth"
                className="sidebar_login"
                onClick={() => setMenuOpen(false)}
              >
                <i className="bi bi-person-fill"></i> Login / Sign Up
              </Link>
            )}
          </div>

          {/* DELIVERY HOURS NOTE */}
          <div className="sidebar_note">
            <i className="bi bi-clock-fill"></i>
            Delivery: 4:00 PM – 3:00 AM
          </div>

        </div>

      </header>

      {/* 🛒 CART DRAWER */}
      <CartDrawer
        isOpen={cartOpen}
        onClose={() => setCartOpen(false)}
        cartItems={cartItems}
        onIncrease={handleIncrease}
        onDecrease={handleDecrease}
        onRemove={handleRemove}
      />
    </>
  );
};

export default Header;