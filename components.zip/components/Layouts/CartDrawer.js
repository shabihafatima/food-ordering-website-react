import React from "react";
import { Link } from "react-router-dom";
import "../../styles/CartDrawer.css";

function CartDrawer({ isOpen, onClose, cartItems, onIncrease, onDecrease, onRemove }) {

  const totalPrice = cartItems.reduce(
    (total, item) => total + (item.price || 0) * (item.quantity || 1),
    0
  );
const user = JSON.parse(localStorage.getItem("currentUser"));
  const totalItems = cartItems.reduce(
    (total, item) => total + (item.quantity || 1),
    0
  );

  return (
    <>
      {/* OVERLAY */}
      <div
        className={`cd_overlay ${isOpen ? "active" : ""}`}
        onClick={onClose}
      ></div>

      {/* DRAWER */}
      <div className={`cd_drawer ${isOpen ? "active" : ""}`}>

        {/* HEADER */}
        <div className="cd_header">
          <div className="cd_title">
            <i className="bi bi-bag-fill me-2"></i>
            Your Cart
            {totalItems > 0 && (
              <span className="cd_count">{totalItems}</span>
            )}
          </div>
          <button className="cd_close" onClick={onClose}>
            <i className="bi bi-x-lg"></i>
          </button>
        </div>

        {/* BODY */}
        <div className="cd_body">
          {cartItems.length === 0 ? (

            /* EMPTY STATE */
            <div className="cd_empty">
              <div className="cd_empty_icon">🍔</div>
              <h5>Your cart is empty</h5>
              <p>Add some delicious burgers to get started!</p>
              <button className="cd_browse_btn" onClick={onClose}>
                Browse Menu
              </button>
            </div>

          ) : (

            /* ITEMS */
            <div className="cd_items">
              {cartItems.map((item) => (
                <div className="cd_item" key={item.id}>

                  {/* IMAGE */}
                  <div className="cd_item_img">
                    <img src={item.image} alt={item.title} />
                  </div>

                  {/* INFO */}
                  <div className="cd_item_info">
                    <h6>{item.title}</h6>
                    <p>Rs. {item.price}</p>

                    {/* QTY CONTROLS */}
                    <div className="cd_qty">
                      <button onClick={() => onDecrease(item.id)}>−</button>
                      <span>{item.quantity || 1}</span>
                      <button onClick={() => onIncrease(item.id)}>+</button>
                    </div>
                  </div>

                  {/* SUBTOTAL + REMOVE */}
                  <div className="cd_item_right">
                    <p className="cd_subtotal">
                      Rs. {(item.price || 0) * (item.quantity || 1)}
                    </p>
                    <button
                      className="cd_remove"
                      onClick={() => onRemove(item.id)}
                      title="Remove item"
                    >
                      <i className="bi bi-trash3"></i>
                    </button>
                  </div>

                </div>
              ))}
            </div>

          )}
        </div>

        {/* FOOTER */}
        {cartItems.length > 0 && (
          <div className="cd_footer">

            {/* TOTAL */}
            <div className="cd_total">
              <span>Total</span>
              <span className="cd_total_price">Rs. {totalPrice}</span>
            </div>

            {/* CHECKOUT BUTTON */}
            <Link
  to={user ? "/cart" : "/auth"}
  onClick={onClose}
  className="cd_checkout_btn"
>
  {user ? "Proceed to Checkout" : "Login to Checkout"}
  <i className="bi bi-arrow-right ms-2"></i>
</Link>

            {/* CONTINUE SHOPPING */}
            <button className="cd_continue" onClick={onClose}>
              Continue Shopping
            </button>

          </div>
        )}

      </div>
    </>
  );
}

export default CartDrawer;