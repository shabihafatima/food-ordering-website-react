import React, { useState } from "react";
import "../../styles/DeliveryPopup.css";

const DELIVERY_AREAS = [
  "Satellite Town",
  "Civil Lines",
  "G.T. Road",
  "Shaheenabad",
  "Peoples Colony",
  "Gujranwala Cantonment",
  "Rahwali",
  "Gondlanwala",
  "Model Town",
  "Qila Didar Singh",
  "Alipur Chatha",
  "Wazirabad Road",
];

function DeliveryPopup({ onClose }) {
  const [selected, setSelected] = useState("");
  const [notAvailable, setNotAvailable] = useState(false);

  const handleConfirm = () => {
    if (!selected && !notAvailable) return;

    const user = JSON.parse(localStorage.getItem("currentUser"));

    if (notAvailable) {
      // Save as "outside area" so popup doesn't show again
      const data = { area: "Outside Gujranwala", timestamp: Date.now() };
      if (user) {
        localStorage.setItem(`delivery_area_${user.email}`, JSON.stringify(data));
      } else {
        sessionStorage.setItem("delivery_area_guest", JSON.stringify(data));
      }
      onClose("Outside Gujranwala");
      return;
    }

    const data = { area: selected, timestamp: Date.now() };
    if (user) {
      localStorage.setItem(`delivery_area_${user.email}`, JSON.stringify(data));
    } else {
      sessionStorage.setItem("delivery_area_guest", JSON.stringify(data));
    }

    onClose(selected);
  };

  const handleNotMyArea = () => {
    setNotAvailable(true);
    setSelected("");
  };

  return (
    <div className="dp_overlay">
      <div className="dp_box">

        {/* Header */}
<div className="dp_header">
  <button
    className="dp_close_btn"
    onClick={() => onClose("skipped")}
  >
    <i className="bi bi-x-lg"></i>
  </button>
  <div className="dp_icon">🛵</div>
  <h2>Where are we delivering?</h2>
  <p>Select your area to check delivery availability</p>
</div>

        {/* Not Available Warning */}
        {notAvailable && (
          <div className="dp_warning">
            <p>⚠️ Sorry, we don't deliver to your area yet.</p>
            <p>You can still browse our menu — we're expanding soon!</p>
            <button
              className="dp_warning_close"
              onClick={() => setNotAvailable(false)}
            >
              ✕
            </button>
          </div>
        )}

        {/* Areas Grid */}
        {!notAvailable && (
          <div className="dp_areas">
            {DELIVERY_AREAS.map((area) => (
              <button
                key={area}
                className={`dp_area_btn ${selected === area ? "active" : ""}`}
                onClick={() => setSelected(area)}
              >
                <i className="bi bi-geo-alt-fill"></i>
                {area}
              </button>
            ))}

            {/* Not in list */}
            <button
              className="dp_area_btn dp_other"
              onClick={handleNotMyArea}
            >
              <i className="bi bi-x-circle"></i>
              My area is not listed
            </button>
          </div>
        )}

        {/* Confirm Button */}
        <button
          className="dp_confirm_btn"
          disabled={!selected && !notAvailable}
          onClick={handleConfirm}
        >
          {notAvailable
            ? "Browse Menu Anyway →"
            : selected
            ? `Deliver to ${selected} ✓`
            : "Select your area first"}
        </button>

        <p className="dp_note">
          <i className="bi bi-clock"></i> Delivery hours: 12:00 PM – 3:00 AM
        </p>

      </div>
    </div>
  );
}

export default DeliveryPopup;